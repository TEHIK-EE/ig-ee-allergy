# Example Patient - EE TIS Allergy IG v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example Patient**

## Example Patient: Example Patient

John Doe Male, DoB: 1980-01-01

-------



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "example",
  "name" : [
    {
      "family" : "Doe",
      "given" : ["John"]
    }
  ],
  "gender" : "male",
  "birthDate" : "1980-01-01"
}

```

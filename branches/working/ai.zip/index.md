# Home - EE TIS Allergy IG v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://fhir.ee/allergy/ImplementationGuide/ig-ee-allergy | *Version*:0.1.0 |
| Draft as of 2025-11-18 | *Computable Name*:EETISIGAllergy |

### Intro

This implementation guide is for the allergy and intolerances data exchange in the context of patient summary and cross boarder activities.

#### Source code

This IG source code is available in [GitHub](https://github.com/TEHIK-EE/ig-ee-starter).

### How to start

1. Copy project and rename project.
1. Replace this IG specific values: look for comments marked**REPLACE_ME:**
1. Remove unnecessary pages, fsh files etc., look for comments marked**REMOVE_ME:**
1. Add domain specific profiles, markdown pages etc.
1. Change alias.fsh and include your domain specific values, please follow the naming pattern.

### Learning resources

* [FSH starter guide](https://fshschool.org/) (describes how to start with IG development using FSH)
* [FHIR Shorthand (FSH) documentation](https://build.fhir.org/ig/HL7/fhir-shorthand/)
* [IG guidance](https://build.fhir.org/ig/FHIR/ig-guidance/) (describes how to style IG, structure and manage content, best practices, etc.)
* [IG publisher documentation](https://confluence.hl7.org/spaces/FHIR/pages/35718627/IG+Publisher+Documentation)

### Structure

**input/fsh/*.fsh** files are logically grouped into folders, which are used to generate the website structure. Please follow the same structure when adding new files.

**input/pagecontent** folder contains markdown files which are used to generate the website pages. Menu and page name mappings are defined in **sushi-config.yaml** file.

### Build and deploy

Building and deploying information is located in [GitHub](https://github.com/TEHIK-EE/ig-ee-starter) project [README](https://github.com/TEHIK-EE/ig-ee-starter/blob/main/README.md) file.


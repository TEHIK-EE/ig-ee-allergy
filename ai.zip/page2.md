# Sample page 2 - EE TIS Allergy IG v0.1.0

* [**Table of Contents**](toc.md)
* **Sample page 2**

## Sample page 2

### Paragraph #1

#### Subparagraph #1.1


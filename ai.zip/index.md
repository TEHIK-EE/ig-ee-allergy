# Home - EE TIS Allergy IG v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://fhir.ee/allergy/ImplementationGuide/ig-ee-allergy | *Version*:0.1.0 |
| Draft as of 2026-09-14 | *Computable Name*:EETISIGAllergy |

### Intro

This implementation guide is for the allergy and intolerances data exchange in the context of patient summary and cross boarder activities.

#### Source code

This IG source code is available in [GitHub](https://github.com/TEHIK-EE/ig-ee-allergy).

